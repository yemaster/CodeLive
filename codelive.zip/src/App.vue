<template>
    <router-view />
    <div class="footer">
        CopyRight &copy; {{ year }} yemaster.
    </div>
</template>

<script>
export default {
    data () {
        return {
            year: new Date().getFullYear()
        }
    }
}
</script>
