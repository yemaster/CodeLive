<script setup>
// Naive-ui components
import { NSplit, NTabs, NTabPane, NH2, NDivider, NCard, NRadioGroup, NRadio, NScrollbar } from 'naive-ui'
import { GameControllerOutline, GameController } from '@vicons/ionicons5'

// monaco-editor units
import * as monaco from 'monaco-editor';

import htmlWorker from 'monaco-editor/esm/vs/language/html/html.worker?worker'
import editorWorker from 'monaco-editor/esm/vs/editor/editor.worker?worker'

import { nextTick, ref, watch } from 'vue'
import { useRoute } from 'vue-router'

// result dom
const resultShow = ref()

// code Content
let codeContent = ref("")

// monaco-editor set
self.MonacoEnvironment = {
    getWorker(_, label) {
        if (label === 'html' || label === 'handlebars' || label === 'razor') {
            return new htmlWorker()
        }
        return new editorWorker()
    },
}

let editor

const editorInit = () => {
    nextTick(() => {
        !editor ? editor = monaco.editor.create(document.getElementById('codeEditor'), {
            value: codeContent.value,
            language: 'html',
            theme: 'vs',
            automaticLayout: true,
            readOnly: false,
            fontSize: 16,
            scrollBeyondLastLine: false,
        }) : editor.setValue("")
        editor.onDidChangeModelContent((val) => {
            codeContent.value = editor.getValue();
            if (resultShow?.value) {
                const ifr = document.createElement("iframe")
                ifr.setAttribute("frameborder", "0")
                ifr.setAttribute("id", "iframeResult")
                ifr.setAttribute("width", "100%")
                ifr.setAttribute("height", "100%")
                resultShow.value.innerHTML = ""
                resultShow.value.appendChild(ifr)
                const ifrw = (ifr.contentWindow) ? ifr.contentWindow : (ifr.contentDocument.document) ? ifr.contentDocument.document : ifr.contentDocument
                ifrw.document.open()
                ifrw.document.write(codeContent.value)
                ifrw.document.close()
            }
        })
    })
}

editorInit()

let combineDirection = ref("vertical")
let tabPosition = ref("top")
let isDragging = ref(false)

function handleOnDragStart() {
    isDragging.value = true
}
function handleOnDragEnd() {
    isDragging.value = false
}

const route = useRoute()
const roomId = ref(route.params.id)
</script>

<template>
    <n-split direction="horizontal" @drag-start="handleOnDragStart" @drag-end="handleOnDragEnd" style="height: 100vh"
        :min="0.25" :max="0.75">
        <template #1>
            <!--combine-editor :combineDirection="combineDirection">
                <template #codeEditor>
                    <code-editor v-model="codeContent"></code-editor>
                </template>
                <template #resultShow>
                    <iframe ref="resultShow"></iframe>
                </template>
            </combine-editor-->
            <n-split :direction="combineDirection" @drag-start="handleOnDragStart" @drag-end="handleOnDragEnd"
                style="height: 100vh" :min="0.25" :max="0.75">
                <template #1>
                    <div id="codeEditor" style="height: 100%; width: 100%"></div>
                </template>
                <template #2>
                    <div class="resultBox">
                        <div class="resultMog" v-show="isDragging"></div>
                        <div class="resultShow" ref="resultShow"></div>
                    </div>
                </template>
            </n-split>
        </template>
        <template #2>
            <n-tabs :placement="tabPosition" type="line" animated :tabs-padding="20">
                <n-tab-pane display-directive="show" name="chat" tab="聊天">
                </n-tab-pane>
                <n-tab-pane display-directive="show" name="info" tab="信息">
                    <n-scrollbar style="height: calc(100% - 16px); width: calc(100% - 40px); padding: 8px 20px;"
                        :x-scrollable="true">
                        <n-h2>信息</n-h2>
                        <n-divider title-placement="left">
                            房间信息
                        </n-divider>
                        <n-card title="房间ID" size="small">
                            {{ roomId }}
                        </n-card>
                    </n-scrollbar>
                </n-tab-pane>
                <n-tab-pane display-directive="show" name="settings" tab="设置">
                    <n-scrollbar style="height: calc(100% - 16px); width: calc(100% - 40px); padding: 8px 20px;"
                        :x-scrollable="true">
                        <n-h2>设置</n-h2>
                        <n-divider title-placement="left">
                            界面设置
                        </n-divider>
                        <n-card title="代码预览排布" size="small">
                            <n-radio-group v-model:value="combineDirection">
                                <n-radio label="横向" value="horizontal" />
                                <n-radio label="纵向" value="vertical" />
                            </n-radio-group>
                        </n-card>
                        <n-card title="右栏标签页位置" size="small">
                            <n-radio-group v-model:value="tabPosition">
                                <n-radio label="左侧" value="left" />
                                <n-radio label="上侧" value="top" />
                                <n-radio label="右侧" value="right" />
                            </n-radio-group>
                        </n-card>
                        <n-divider title-placement="left">
                            编辑器设置
                        </n-divider>
                    </n-scrollbar>
                </n-tab-pane>
            </n-tabs>
        </template>
    </n-split>
</template>

<style scoped>
.resultBox {
    position: relative;
    width: 100%;
    height: 100%;
}

.resultMog {
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    z-index: 100;
    background-color: transparent;
}

.resultShow {
    width: 100%;
    height: 100%;
}

.n-card {
    margin-top: 10px;
}
</style>