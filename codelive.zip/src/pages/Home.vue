<script setup>
import { NH1, NInput, NButton, NInputGroup } from 'naive-ui'
import { ref } from 'vue'
import { useRouter } from 'vue-router'

let roomId = ref("")
const router = useRouter()

function randId() {
    const words = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890"
    let res = ""
    for (let i = 0; i < 6; ++i)
        res += words[Math.floor(Math.random() * words.length)]
    return res
}

function enterRoom() {
    if (roomId.length !== 6) {
        roomId = randId()
    }
    router.push({
        name: "Room",
        params: { id: roomId }
    })
}
</script>

<template>
    <div class="show">
        <n-h1>U5TC Code Live Platform</n-h1>
        <n-input-group>
            <n-input v-model:value="roomId" type="text" placeholder="输入Live Room ID" />
            <n-button type="primary" @click="enterRoom">
                进入
            </n-button>
        </n-input-group>
    </div>
</template>

<style scoped>
.show {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
}
</style>